var locData = [];
locData["lang"] = "en";

locData["bravo"]=
	{font:"Lato",
	es:"¡Bravo por Pocoyo!",
	en:"Hurray for Pocoyo!",
	en_US:"Hurray for Pocoyo!",
	it:"Urrà per Pocoyo!",
	pt:"Boa, Pocoyó!",
	zh:"太棒了，优优！"};

locData["Title"]=
	{font:"Lato",
	es:"Juguemos al golf",
	en:"Let's play golf",
	en_US:"Let's play golf",
	it:"Giochiamo a golf",
	pt:"Vamos jogar golfe",
	zh:"让我们来玩高尔夫"};